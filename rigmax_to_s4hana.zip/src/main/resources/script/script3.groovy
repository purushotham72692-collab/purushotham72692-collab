import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    // Get caught exception
    def exception = message.getProperty("CamelExceptionCaught")

    // Default error message
    String errorMessage = "Unknown integration error"

    // Extract actual exception message
    if (exception != null) {

        errorMessage = exception.getMessage()

        if (errorMessage == null ||
            errorMessage.trim().isEmpty()) {

            errorMessage = exception.toString()
        }
    }

    // Get PO number
    String poNumber = message.getProperty("PONumber")

    if (poNumber == null ||
        poNumber.trim().isEmpty()) {

        poNumber = "UNKNOWN"
    }

    // Get business action
    String businessAction =
        message.getProperty("BusinessAction")

    if (businessAction == null ||
        businessAction.trim().isEmpty()) {

        businessAction = "UNKNOWN"
    }

    // Set error properties
    message.setProperty(
        "ExceptionMessage",
        errorMessage
    )

    message.setProperty(
        "ExceptionPONumber",
        poNumber
    )

    message.setProperty(
        "ExceptionBusinessAction",
        businessAction
    )

    // Error status
    message.setProperty(
        "ProcessingStatus",
        "ERROR"
    )

    return message
}