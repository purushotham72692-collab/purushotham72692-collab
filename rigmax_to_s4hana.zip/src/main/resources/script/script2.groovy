import com.sap.gateway.ip.core.customdev.util.Message
import java.math.BigDecimal

def Message processData(Message message) {

    BigDecimal poAmount = new BigDecimal(
        message.getProperty("POAmount").toString()
    )

    BigDecimal invoiceAmount = new BigDecimal(
        message.getProperty("InvoiceAmount").toString()
    )

    BigDecimal commitmentAmount =
        poAmount.subtract(invoiceAmount)

    message.setProperty(
        "CommitmentAmount",
        commitmentAmount.toPlainString()
    )

    return message
}