import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.io.Reader
import java.math.BigDecimal

def Message processData(Message message) {

    // Read split XML
    Reader reader = message.getBody(Reader)

    def xml

    try {
        xml = new XmlSlurper().parse(reader)
    } catch (Exception e) {
        throw new IllegalArgumentException(
            "Unable to parse PO XML: " + e.getMessage()
        )
    }

    // Validate root
    if (xml.name() != "PORequest") {
        throw new IllegalArgumentException(
            "Invalid root element. Expected PORequest"
        )
    }

    // Get PO
    def po = xml.PO[0]

    if (po.size() == 0) {
        throw new IllegalArgumentException(
            "PO record not found"
        )
    }

    // Read fields
    String poNumber = po.PONumber.text().trim()
    String companyCode = po.CompanyCode.text().trim()
    String vendor = po.Vendor.text().trim()
    String currency = po.Currency.text().trim()

    String poAmountText = po.POAmount.text().trim()
    String grAmountText = po.GRAmount.text().trim()
    String invoiceAmountText = po.InvoiceAmount.text().trim()

    String grStatus = po.GRStatus.text().trim()
    String invoiceStatus = po.InvoiceStatus.text().trim()
    String action = po.Action.text().trim()

    // Mandatory validation
    if (!poNumber) {
        throw new IllegalArgumentException(
            "PONumber is mandatory"
        )
    }

    if (!companyCode) {
        throw new IllegalArgumentException(
            "CompanyCode is mandatory for PO " + poNumber
        )
    }

    if (!vendor) {
        throw new IllegalArgumentException(
            "Vendor is mandatory for PO " + poNumber
        )
    }

    if (!currency) {
        throw new IllegalArgumentException(
            "Currency is mandatory for PO " + poNumber
        )
    }

    // Convert amounts
    BigDecimal poAmount
    BigDecimal grAmount
    BigDecimal invoiceAmount

    try {
        poAmount = new BigDecimal(poAmountText)
        grAmount = new BigDecimal(grAmountText)
        invoiceAmount = new BigDecimal(invoiceAmountText)
    } catch (Exception e) {
        throw new IllegalArgumentException(
            "Invalid amount for PO " + poNumber
        )
    }

    // Amount validation
    if (poAmount.compareTo(BigDecimal.ZERO) < 0) {
        throw new IllegalArgumentException(
            "POAmount cannot be negative for PO " + poNumber
        )
    }

    if (grAmount.compareTo(BigDecimal.ZERO) < 0) {
        throw new IllegalArgumentException(
            "GRAmount cannot be negative for PO " + poNumber
        )
    }

    if (invoiceAmount.compareTo(BigDecimal.ZERO) < 0) {
        throw new IllegalArgumentException(
            "InvoiceAmount cannot be negative for PO " + poNumber
        )
    }

    if (grAmount.compareTo(poAmount) > 0) {
        throw new IllegalArgumentException(
            "GRAmount cannot be greater than POAmount for PO " + poNumber
        )
    }

    if (invoiceAmount.compareTo(poAmount) > 0) {
        throw new IllegalArgumentException(
            "InvoiceAmount cannot be greater than POAmount for PO " + poNumber
        )
    }

    // Status validation
    if (!(grStatus in ["NONE", "PARTIAL", "FULL"])) {
        throw new IllegalArgumentException(
            "Invalid GRStatus '" + grStatus +
            "' for PO " + poNumber
        )
    }

    if (!(invoiceStatus in ["NONE", "PARTIAL", "FULL"])) {
        throw new IllegalArgumentException(
            "Invalid InvoiceStatus '" + invoiceStatus +
            "' for PO " + poNumber
        )
    }

    if (action != "PROCESS") {
        throw new IllegalArgumentException(
            "Invalid Action '" + action +
            "' for PO " + poNumber
        )
    }

    // GR status consistency
    if (
        grStatus == "NONE" &&
        grAmount.compareTo(BigDecimal.ZERO) != 0
    ) {
        throw new IllegalArgumentException(
            "GRStatus is NONE but GRAmount is not zero for PO " +
            poNumber
        )
    }

    if (
        grStatus == "FULL" &&
        grAmount.compareTo(poAmount) != 0
    ) {
        throw new IllegalArgumentException(
            "GRStatus is FULL but GRAmount is not equal to POAmount for PO " +
            poNumber
        )
    }

    if (
        grStatus == "PARTIAL" &&
        (
            grAmount.compareTo(BigDecimal.ZERO) <= 0 ||
            grAmount.compareTo(poAmount) >= 0
        )
    ) {
        throw new IllegalArgumentException(
            "Invalid PARTIAL GRAmount for PO " + poNumber
        )
    }

    // Invoice status consistency
    if (
        invoiceStatus == "NONE" &&
        invoiceAmount.compareTo(BigDecimal.ZERO) != 0
    ) {
        throw new IllegalArgumentException(
            "InvoiceStatus is NONE but InvoiceAmount is not zero for PO " +
            poNumber
        )
    }

    if (
        invoiceStatus == "FULL" &&
        invoiceAmount.compareTo(poAmount) != 0
    ) {
        throw new IllegalArgumentException(
            "InvoiceStatus is FULL but InvoiceAmount is not equal to POAmount for PO " +
            poNumber
        )
    }

    if (
        invoiceStatus == "PARTIAL" &&
        (
            invoiceAmount.compareTo(BigDecimal.ZERO) <= 0 ||
            invoiceAmount.compareTo(poAmount) >= 0
        )
    ) {
        throw new IllegalArgumentException(
            "Invalid PARTIAL InvoiceAmount for PO " +
            poNumber
        )
    }

    // =========================================================
    // BUSINESS DECISION
    // =========================================================

    String businessAction = "NO_UPDATE"

    // TC01: No GR + No Invoice
    if (
        grAmount.compareTo(BigDecimal.ZERO) == 0 &&
        invoiceAmount.compareTo(BigDecimal.ZERO) == 0
    ) {

        businessAction = "UPDATE_REVERSAL"

    }

    // TC02: Full GR + No Invoice
    else if (
        grAmount.compareTo(poAmount) == 0 &&
        invoiceAmount.compareTo(BigDecimal.ZERO) == 0
    ) {

        businessAction = "NO_UPDATE"

    }

    // TC03: Full GR + Full Invoice
    else if (
        grAmount.compareTo(poAmount) == 0 &&
        invoiceAmount.compareTo(poAmount) == 0
    ) {

        businessAction = "NO_UPDATE"

    }

    // TC04: Full GR + Partial Invoice
    else if (
        grAmount.compareTo(poAmount) == 0 &&
        invoiceAmount.compareTo(BigDecimal.ZERO) > 0 &&
        invoiceAmount.compareTo(poAmount) < 0
    ) {

        businessAction = "UPDATE_REVERSAL"

    }

    // TC05: Partial GR + No Invoice
    else if (
        grAmount.compareTo(BigDecimal.ZERO) > 0 &&
        grAmount.compareTo(poAmount) < 0 &&
        invoiceAmount.compareTo(BigDecimal.ZERO) == 0
    ) {

        businessAction = "NO_UPDATE"

    }

    // TC06: Partial GR + Partial Invoice
    else if (
        grAmount.compareTo(BigDecimal.ZERO) > 0 &&
        grAmount.compareTo(poAmount) < 0 &&
        invoiceAmount.compareTo(BigDecimal.ZERO) > 0 &&
        invoiceAmount.compareTo(poAmount) < 0
    ) {

        businessAction = "UPDATE_REVERSAL"

    }

    // TC07: No GR + Partial Invoice
    else if (
        grAmount.compareTo(BigDecimal.ZERO) == 0 &&
        invoiceAmount.compareTo(BigDecimal.ZERO) > 0 &&
        invoiceAmount.compareTo(poAmount) < 0
    ) {

        businessAction = "UPDATE_REVERSAL"
    }

    // Set properties
    message.setProperty("PONumber", poNumber)
    message.setProperty("CompanyCode", companyCode)
    message.setProperty("Vendor", vendor)
    message.setProperty("Currency", currency)

    message.setProperty(
        "POAmount",
        poAmount.toPlainString()
    )

    message.setProperty(
        "GRAmount",
        grAmount.toPlainString()
    )

    message.setProperty(
        "InvoiceAmount",
        invoiceAmount.toPlainString()
    )

    message.setProperty("GRStatus", grStatus)
    message.setProperty("InvoiceStatus", invoiceStatus)
    message.setProperty("BusinessAction", businessAction)

    return message
}